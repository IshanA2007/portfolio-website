---
name: ishan-portfolio-design
description: Use this skill to generate well-branded interfaces and assets for Ishan's personal portfolio (light mode, nature-green accent), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

Key files:
- `README.md` — content fundamentals, visual foundations, iconography
- `colors_and_type.css` — drop-in CSS variables (colors, type, spacing, radii, shadows)
- `assets/logos/` — tech vendor logos (React, Next, Tailwind, Postgres, etc.)
- `assets/section-flower.svg` — the spinning section-marker icon
- `preview/` — small reference cards for each token group
- `ui_kits/portfolio/` — full retuned portfolio site (HTML + JSX components)

If creating visual artifacts (slides, mocks, throwaway prototypes, etc.), copy assets out and create static HTML files for the user to view, importing `colors_and_type.css` for tokens.

If working on production code (Next.js + Tailwind), translate the CSS variables in `colors_and_type.css` into Tailwind theme tokens, and lift component patterns from `ui_kits/portfolio/`.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (audience, surface, copy direction), and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

**Brand-critical do's & don'ts**
- Anton (display, all-caps) + Roboto Flex (body). No third family.
- Forest green `#3F7D3A` is the only accent color used for emphasis.
- Buttons stay sharp-cornered; cards round to 8px.
- Section titles always pair with the spinning flower icon.
- Project rows are numbered `_01.`, `_02.` in muted Anton.
- No emoji in chrome (nav/buttons/headers); emoji okay in long project copy.
- Custom cursor + slide-up-and-fade scroll animations are signature.
