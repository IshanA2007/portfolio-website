# Ishan Portfolio — Design System

A design system for **Ishan A.**'s personal portfolio site — a CS student at the
University of Virginia interested in software development and AI/ML. This
system is a **light-mode, nature-green** reinterpretation of his existing
portfolio (originally a dark theme with neon-green accents). The animations,
layout, typography rhythm and component vocabulary are kept faithful; only the
palette and font intent have been re-skinned.

## Source

- **Codebase:** `IshanA2007/portfolio-website` (Next.js 15, App Router,
  TypeScript, Tailwind v3, GSAP + Lenis). Read on demand via the project's
  GitHub tools.
- **Original Figma design:** referenced in the repo's README
  ([New Portfolio](https://www.figma.com/design/56hODoGFDzZfZduBPfQeBg/New-Portfolio?node-id=18-1550)).
  The codebase implements this design — codebase is the source of truth.
- **Original author note:** the codebase is a fork of Tajmirul Islam's open
  source portfolio. Ishan is using it as the scaffolding for his own site;
  this design system retunes it to his identity (CS student, AI/ML focus,
  nature-green light theme) rather than the original dark-mode "frontend
  developer" framing.

## Index

- `colors_and_type.css` — CSS variables for the entire system (colors,
  typography, spacing, radius, shadow). Import this anywhere.
- `assets/logos/` — tech-stack logos (React, Next.js, Tailwind, etc.) lifted
  directly from the original `public/logo` directory.
- `assets/section-flower.svg` — the small spinning flower icon used as a
  section marker on the original site.
- `preview/` — design-system preview cards (one per token group / component
  cluster). Each is registered in the Design System tab.
- `ui_kits/portfolio/` — high-fidelity recreation of the portfolio site
  itself, retuned to the new light-green palette. `index.html` is a
  click-through prototype; component JSX files live alongside.
- `SKILL.md` — agent skill manifest; lets this system be invoked from
  Claude Code.

## What changed from the original

| Area | Original | This system |
| --- | --- | --- |
| Mode | Dark (`#212121` bg, `#ddd` text) | Light (`#F7F6F1` bg, `#1B2118` text) |
| Accent | Neon green `hsl(140 100% 47%)` | Forest green `#3F7D3A` |
| Secondary accent | Cyan `hsl(193 100% 47%)` | Leaf green `#6FA34A` |
| Display font | Anton | Anton (kept) |
| Body font | Roboto Flex | Roboto Flex (kept) |
| Section title | "Frontend Developer" | "Software Developer / AI · ML" (Ishan-specific) |
| Anims | GSAP scroll, custom cursor, preloader, particle bg | All kept |

---

## CONTENT FUNDAMENTALS

The site's voice is **first-person, casual-confident, low-jargon**. Ishan
talks about himself directly without resume-speak; copy is short, punchy, and
leans on big condensed display type to do the heavy lifting.

**Voice rules**

- **First person, present tense.** "Hi, I'm Ishan." — never "Ishan is a…".
- **Contractions allowed.** "I'm", "don't", "let's" — keeps it personable.
- **Casing:** display-type headings are **ALL CAPS** (Anton is uppercase by
  design). Body copy is **sentence case**. Section eyebrows ("My Stack", "My
  Experience", "Selected Projects") are **Title Case** or **UPPERCASE LABEL**
  with wide letter-spacing.
- **Tone:** confident but understated. State facts, then a one-line "why it
  matters" tail. Avoid superlatives ("amazing", "world-class") — let the
  projects speak.
- **No emoji in UI chrome.** The original codebase uses emoji only inside
  long-form project description bodies (e.g. `🛠️`, `✍️`) — this system keeps
  that boundary: emoji is fine inside markdown-style project copy, but never
  in nav, buttons, headers, or section titles.
- **Numbers & stats are big.** Hero shows `3+ Years`, `7+ Projects`, etc., in
  display type. Use this pattern for any quantitative brag.
- **Project listings** start with `_01.`, `_02.` — underscore + zero-padded
  index, in muted Anton. This is a signature pattern; preserve it.

**Sample copy (from the codebase, retuned for Ishan)**

> "Hi! I'm Ishan. A CS student at UVA building tools at the intersection of
> software engineering and AI/ML — focused on responsive interfaces,
> data-driven systems, and the occasional CV experiment."

> "I believe in building software that's simple to use and honest about what
> it does."

> "Have a project in mind?"  *(footer CTA — verbatim from the original)*

---

## VISUAL FOUNDATIONS

**Colors.** Warm off-white page (`#F7F6F1`) — paper, not glare-white. Ink is
`#1B2118` (near-black with a green undertone, so it harmonises with the
accent). Primary accent is **forest green `#3F7D3A`** — used sparingly: hero
word ("DEVELOPER" gets the accent treatment), button fills, the scroll
progress bar, hover states, the gradient sweep on project titles. Secondary
**leaf green `#6FA34A`** for tech badges and chart-style elements. A warm
**cream `#F1ECDC`** is reserved for hero/eyebrow blocks; **bark brown
`#4A3A2A`** is the contrast color for any dark-on-light element (footer dark
band, drawer panel).

**Type.** Two fonts, full stop. **Anton** (condensed sans, single weight 400,
always uppercase) does every display moment — h1/h2/h3, project titles, stat
numbers, the preloader name, button labels. **Roboto Flex** (variable; we
ship 100/300/400/500/600/700/800) does body, eyebrow labels, meta. The
contrast between condensed-display Anton and wide-body Roboto Flex is the
central type rhythm — don't add a third family.

**Spacing.** Generous. Section padding is huge (originally 250px,
trimmed here to 160px for legibility). Cards & rows use `gap` in flex/grid;
inner padding is 16–32px. The container caps at 1148px.

**Backgrounds.** Mostly flat warm off-white. The original adds:

- A **particle background** (subtle floating dots) — a faint motion layer.
  Keep at very low opacity in light mode (`rgba(63, 125, 58, 0.18)` or so).
- An **animated arrow SVG** in the hero (`ArrowAnimation.tsx`) that draws and
  fills.
- Page-transition wipe on route change (`template.tsx`) — a colored panel
  slides up over the page on navigation. Use **`var(--primary)`** for the
  inner wipe and **`var(--bg-tint)`** for the outer.
- No gradients beyond the project-title hover sweep (`from-primary` →
  `from-foreground`, animated via `bg-position`). No image full-bleeds;
  imagery is contained inside project cards.

**Animation.** GSAP + ScrollTrigger throughout. Three motifs:

1. **Slide-up-and-fade** — content enters with `y: 150 → 0, opacity: 0 → 1,
   stagger 0.02–0.05`, then exits with `y: 0 → -150, opacity → 0` as it
   leaves the viewport. Scrubbed to scroll, not time-based.
2. **Stroke draw-on** — SVG `strokeDashoffset` animations (the hero arrow,
   project external-link icon, preloader). 1–2s duration.
3. **Slow rotation** — section flower icon spins continuously
   (`animate-spin duration-7000` = 7s/turn).

Easings: `power1.inOut`, `power2.out`. No bounce, no elastic. Everything
feels editorial and restrained.

**Hover states.**

- Links: color → `var(--primary)`.
- Project rows: the hovered row stays full opacity; siblings fade to 30%
  opacity (`group-hover/projects:opacity-30 hover:!opacity-100`).
- Buttons: a white/cream pill slides up from below, scaled 150%, replacing
  the fill (`top-[200%] → top-0` on hover, 500ms).
- Project titles: gradient bg sweeps right→left on hover (700ms).

**Press states.** Slight darken via the `*-hover` color tokens; no scale
transform (the cursor itself is the feedback — the site has a **custom
cursor**, not the system default).

**Borders.** 1px hairlines in `var(--border)` (`#D8D7CE`). Used between
project rows and as the underline beneath section eyebrows. No double
borders, no thick strokes anywhere.

**Shadows.** Light theme means soft shadows: `0 4px 14px rgba(27,33,24,0.08)`
for cards, `0 18px 40px -12px rgba(27,33,24,0.18)` for floating panels. The
original dark version barely uses shadow at all — we add a little here for
elevation cues.

**Radii.** Subtle. `8px` default, `4px` for inline pills/badges, `999px`
only for full pills (the small 3px status dot, social-icon dots in the menu).
Buttons in the original use **no rounding** (sharp rectangles) for the main
CTA — preserve this; rounded buttons read as a different brand.

**Transparency / blur.** Used sparingly: the menu drawer overlay is
`bg-black/70` (we use `rgba(27, 33, 24, 0.55)` in light mode), the
project-image floating preview rides over the list at `opacity: 1` once
positioned. No frosted-glass / `backdrop-blur` anywhere — keep the visual
language flat.

**Layout rules.** Container 1148px max, `1rem` side padding. Hero is full
viewport height (`100svh`, min 530px). Section padding 160px below.
Decorative numbers/stats live absolutely-positioned in the hero on desktop,
re-flow inline on mobile.

**Imagery.** Project thumbnails are 3:2 (list view) and 3:4 (hover preview).
No filters, no grayscale; full color, contained. The site does not use any
hand-drawn illustration or texture.

**Cursor.** Custom SVG cursor (an arrow) that follows the mouse with a
GSAP-eased lag. The system hides the OS cursor (`cursor: none` on `*`).
This is a strong signature — keep it for any interactive surface.

---

## ICONOGRAPHY

The original site uses **two distinct icon sources**, and one custom asset:

1. **`lucide-react`** — for all UI chrome icons (`MoveUpRight` in the menu,
   `Star`/`GitFork` in the footer, `ExternalLink` re-drawn inline in the
   project hover animation). Lucide is a 24×24, 2px-stroke, rounded-cap line
   icon set. **Stroke icons only** — no filled lucide variants. We mirror
   this: pull from `lucide-react` (or its CDN equivalent
   [`lucide.dev`](https://lucide.dev) static SVGs) for any chrome icon need.

2. **Hand-coded SVG** — bigger decorative SVGs are inline in components
   (`ArrowAnimation`, the inline `external-link` arrow on project hover,
   the cursor arrow). These are draw-on animated; treat them as motion
   pieces, not generic icons.

3. **`section-flower.svg`** — a one-off 12-petal flower icon used to the left
   of every section title. It spins on a 7-second loop. Imported into
   `assets/section-flower.svg`. **This is the brand's only quirky shape.**
   Use it — sparingly — wherever a section title appears.

**Tech-stack logos** — the homepage's "My Stack" section displays raw vendor
logos (React, Next, Tailwind, etc.) at 40×40px next to the tech name. These
are PNG/SVG files lifted from the original `public/logo` directory and live
in `assets/logos/`. **Use the real vendor marks**; do not redraw or recolor
them.

**Emoji** is allowed only inside long-form project description copy
(matches the original `🛠️ Service Display System` pattern in
`lib/data.ts`). Not in headers, nav, buttons, or labels.

**Unicode chars used as icons:** the project-listing index uses `_01.`,
`_02.` (underscore + zero-padded number) as a numeric prefix. Treat this as
typographic, not iconographic.

---

## Substitutions / flags for the user

- **Logo.** The original codebase has no actual logo mark — Tajmirul's site
  is wordmark-free; the navbar uses only the hamburger menu. This system
  inherits that. If Ishan wants a logo or wordmark, **please send one**;
  otherwise the kit will continue to use his name set in Anton as the
  identity.
- **Fonts.** Both Anton and Roboto Flex are loaded via Google Fonts CDN in
  `colors_and_type.css`. No `.ttf`/`.woff2` files are vendored. If you need
  offline copies, ask and I'll vendor them.
- **Colors.** "Nature green" is a direction, not a brief — I picked a forest
  green (`#3F7D3A`) as primary and a leaf green (`#6FA34A`) as secondary.
  These work on the warm-paper background. **Confirm or send a target
  swatch** if you want a different green.

---

## How to iterate

1. Open the **Design System** tab to see all preview cards.
2. Open `ui_kits/portfolio/index.html` to see the full retuned site.
3. Tell me what to change — colors, type, the green specifically, copy,
   sections.
