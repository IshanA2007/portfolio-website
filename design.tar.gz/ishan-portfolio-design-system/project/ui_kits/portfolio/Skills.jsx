const STACK = {
  frontend: [
    { name: 'React',      icon: '../../assets/logos/react.png' },
    { name: 'Next.js',    icon: '../../assets/logos/next.png' },
    { name: 'TypeScript', icon: '../../assets/logos/ts.png' },
    { name: 'JavaScript', icon: '../../assets/logos/js.png' },
    { name: 'Tailwind',   icon: '../../assets/logos/tailwind.png' },
    { name: 'Sass',       icon: '../../assets/logos/sass.png' },
  ],
  backend: [
    { name: 'Node.js',  icon: '../../assets/logos/node.png' },
    { name: 'Express',  icon: '../../assets/logos/express.png' },
    { name: 'Postgres', icon: '../../assets/logos/postgreSQL.png' },
    { name: 'MongoDB',  icon: '../../assets/logos/mongodb.svg' },
  ],
  'ai / ml': [
    { name: 'Python',  icon: 'https://upload.wikimedia.org/wikipedia/commons/c/c3/Python-logo-notext.svg' },
    { name: 'PyTorch', icon: 'https://upload.wikimedia.org/wikipedia/commons/1/10/PyTorch_logo_icon.svg' },
    { name: 'OpenCV',  icon: 'https://upload.wikimedia.org/wikipedia/commons/3/32/OpenCV_Logo_with_text_svg_version.svg' },
  ],
  tools: [
    { name: 'Git',    icon: '../../assets/logos/git.png' },
    { name: 'Docker', icon: '../../assets/logos/docker.svg' },
    { name: 'AWS',    icon: '../../assets/logos/aws.png' },
  ],
};

function Skills() {
  return (
    <section className="section" id="my-stack">
      <div className="container">
        <SectionTitle title="My Stack" />
        {Object.entries(STACK).map(([key, items], rowIdx) => (
          <div className="skills-row" key={key}>
            <div className="key reveal" data-reveal-delay={rowIdx * 40}>{key}</div>
            <div className="items">
              {items.map((item, i) => (
                <div className="item reveal" data-reveal-delay={rowIdx * 40 + i * 40} key={item.name}>
                  <img src={item.icon} alt={item.name} />
                  <span>{item.name}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
window.Skills = Skills;
