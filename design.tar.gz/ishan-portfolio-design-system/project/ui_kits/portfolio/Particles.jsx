// Falling green particles — kicks in once the user scrolls past hero.
// Slow drift, soft sway, opacity fade — autumnal feel.
function Particles() {
  const canvasRef = React.useRef(null);
  const stateRef = React.useRef({ active: false, particles: [], raf: 0, last: 0 });

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      canvas.width  = Math.floor(window.innerWidth  * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
      canvas.style.width  = window.innerWidth + 'px';
      canvas.style.height = window.innerHeight + 'px';
    };
    resize();
    window.addEventListener('resize', resize);

    const COLORS = [
      'rgba(63,125,58,',   // deep forest
      'rgba(111,163,74,',  // leaf
      'rgba(143,178,99,',  // sage
      'rgba(89,140,67,',
    ];

    const make = (fromTop = false) => {
      const w = window.innerWidth, h = window.innerHeight;
      const r = 1.5 + Math.random() * 2.0;
      return {
        x: Math.random() * w,
        y: fromTop ? -10 - Math.random() * 200 : -Math.random() * h * 0.5,
        r,
        vy: 0.12 + Math.random() * 0.32,
        vx: (Math.random() - 0.5) * 0.14,
        sway: 0.3 + Math.random() * 0.7,
        swayPhase: Math.random() * Math.PI * 2,
        swaySpeed: 0.0006 + Math.random() * 0.0012,
        color: COLORS[(Math.random() * COLORS.length) | 0],
        alpha: 0.30 + Math.random() * 0.45,
        rot: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 0.01,
      };
    };

    const seed = (n) => {
      const arr = stateRef.current.particles;
      for (let i = 0; i < n; i++) {
        const p = make(false);
        p.y = Math.random() * window.innerHeight;
        arr.push(p);
      }
    };

    const onScroll = () => {
      const scrolled = window.scrollY;
      const trigger = 60;
      const wantActive = scrolled > trigger;
      if (wantActive && !stateRef.current.active) {
        stateRef.current.active = true;
        if (stateRef.current.particles.length === 0) seed(20);
      } else if (!wantActive && stateRef.current.active) {
        stateRef.current.active = false;
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    const tick = (t) => {
      const s = stateRef.current;
      const dt = s.last ? Math.min(t - s.last, 50) : 16;
      s.last = t;
      const w = canvas.width, h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      if (s.active && s.particles.length < 30) {
        if (Math.random() < 0.10) s.particles.push(make(true));
      }

      const arr = s.particles;
      for (let i = arr.length - 1; i >= 0; i--) {
        const p = arr[i];
        p.swayPhase += p.swaySpeed * dt;
        const sx = Math.sin(p.swayPhase) * p.sway;
        p.x += (p.vx + sx * 0.3) * (dt / 16);
        p.y += p.vy * (dt / 16);
        p.rot += p.vr;

        // fade out when inactive
        if (!s.active) {
          p.alpha *= 0.985;
          if (p.alpha < 0.02) { arr.splice(i, 1); continue; }
        }

        if (p.y * dpr > h + 20) { arr.splice(i, 1); continue; }
        if (p.x < -20) p.x = window.innerWidth + 10;
        if (p.x > window.innerWidth + 20) p.x = -10;

        // small leaf-like soft circle
        const px = p.x * dpr, py = p.y * dpr, pr = p.r * dpr;
        const grad = ctx.createRadialGradient(px, py, 0, px, py, pr * 2.2);
        grad.addColorStop(0, p.color + (p.alpha) + ')');
        grad.addColorStop(1, p.color + '0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(px, py, pr * 2.2, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = p.color + Math.min(1, p.alpha + 0.2) + ')';
        ctx.beginPath();
        ctx.arc(px, py, pr, 0, Math.PI * 2);
        ctx.fill();
      }

      s.raf = requestAnimationFrame(tick);
    };
    stateRef.current.raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(stateRef.current.raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="particles-canvas"
      aria-hidden="true"
    />
  );
}
window.Particles = Particles;
