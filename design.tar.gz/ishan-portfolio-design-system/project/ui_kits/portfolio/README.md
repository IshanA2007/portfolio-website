# Portfolio UI Kit — Ishan

A high-fidelity recreation of the portfolio site retuned with the light + nature-green palette.

## Components
- `Navbar.jsx` — top-right hamburger + slide-in drawer menu
- `Hero.jsx` — full-viewport hero with animated arrow + stat block
- `AboutMe.jsx` — quiet headline + two-column body
- `Skills.jsx` — tech stack grid with vendor logos
- `Experiences.jsx` — list of roles
- `Projects.jsx` — numbered project rows with hover-image preview
- `Footer.jsx` — CTA email + GitHub stats
- `SectionTitle.jsx` — spinning flower + uppercase label
- `Button.jsx` — Anton-label CTA, sharp corners, sweep on hover
- `Cursor.jsx` — custom arrow cursor following the mouse

## Source
Recreated against `IshanA2007/portfolio-website` (Next.js + Tailwind + GSAP). Visuals match; implementation is simplified vanilla React + CSS variables from `colors_and_type.css`.

Open `index.html` for the click-through prototype.
