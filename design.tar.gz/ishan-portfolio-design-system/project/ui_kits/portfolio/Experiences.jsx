const EXPERIENCES = [
  { title: 'Software Engineering Intern', company: 'TBD — Summer 2026', duration: 'Jun 2026 – Aug 2026' },
  { title: 'Undergraduate Researcher (AI/ML)', company: 'University of Virginia', duration: 'Sep 2024 – Present' },
  { title: 'Web Developer', company: 'DSSD @ UVA', duration: 'Jan 2024 – Present' },
  { title: 'Software Lead', company: 'TJ UAV', duration: 'Aug 2022 – Jun 2024' },
];

function Experiences() {
  return (
    <section className="section section-lg" id="my-experience">
      <div className="container">
        <SectionTitle title="My Experience" />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 56 }}>
          {EXPERIENCES.map((e, i) => (
            <div className="exp reveal" data-reveal-delay={i * 60} key={e.title + e.company}>
              <div className="company">{e.company}</div>
              <div className="title">{e.title}</div>
              <div className="duration">{e.duration}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
window.Experiences = Experiences;
