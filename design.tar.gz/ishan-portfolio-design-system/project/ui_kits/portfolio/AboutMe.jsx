function AboutMe() {
  return (
    <section className="section section-lg" id="about-me">
      <div className="container">
        <h2 className="headline-quiet reveal">
          I build software that's simple to use and honest about what it does — and I love when the user-facing surface is as careful as the model behind it.
        </h2>

        <span className="eyebrow reveal" data-reveal-delay="60">_01.&nbsp; This is me</span>

        <div style={{ display: 'grid', gridTemplateColumns: '5fr 7fr', gap: 32 }}>
          <p className="reveal" data-reveal-delay="120" style={{ fontSize: 36, fontFamily: 'var(--font-body)', fontWeight: 300, margin: 0, lineHeight: 1.1 }}>
            Hi, I'm Ishan.
          </p>
          <div style={{ maxWidth: 480, color: 'var(--fg-soft)', fontSize: 17, lineHeight: 1.6 }}>
            <p className="reveal" data-reveal-delay="180" style={{ margin: 0 }}>
              I'm a CS student at the University of Virginia who likes turning rough ideas into working software. I gravitate toward problems where a clean interface and a smart model have to share the same screen.
            </p>
            <p className="reveal" data-reveal-delay="240" style={{ marginTop: 14, marginBottom: 0 }}>
              Lately I've been working on full-stack web projects, AI-assisted developer tools, and a few computer-vision experiments on the side. I care about responsiveness, accessibility, and making things that other students can actually use.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
window.AboutMe = AboutMe;
