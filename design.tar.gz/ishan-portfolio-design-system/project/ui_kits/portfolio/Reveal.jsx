// Continuous scroll-driven reveal — replaces the IntersectionObserver-based one.
// Every frame (rAF, throttled to scroll/resize), assess each .reveal element's
// position and assign a state class so animations fire reliably regardless of scroll speed.
//
// States:
//   (none)        element is below viewport, hasn't entered → hidden, translateY(+60)
//   .is-visible   element is in the comfortable read zone  → opacity 1, translateY(0)
//   .is-leaving   element has scrolled past the top edge   → opacity 0, translateY(-90)
function useReveal() {
  React.useEffect(() => {
    let raf = 0;
    let dirty = true;

    const recompute = () => {
      const els = document.querySelectorAll('.reveal');
      const vh = window.innerHeight;
      // Trigger when the element's top crosses ~88% of viewport height.
      // Mark as leaving when its bottom crosses ~12% (scrolled well past).
      const enterAt = vh * 0.88;
      const leaveAt = vh * 0.12;
      for (const el of els) {
        const r = el.getBoundingClientRect();
        const top = r.top;
        const bottom = r.bottom;
        if (bottom < leaveAt) {
          // scrolled past — slide up + fade out
          if (!el.classList.contains('is-leaving')) {
            el.classList.add('is-leaving');
            el.classList.remove('is-visible');
          }
        } else if (top < enterAt) {
          if (!el.classList.contains('is-visible')) {
            el.classList.add('is-visible');
            el.classList.remove('is-leaving');
          }
        } else {
          // not yet entered from below — keep initial
          if (el.classList.contains('is-visible') || el.classList.contains('is-leaving')) {
            el.classList.remove('is-visible');
            el.classList.remove('is-leaving');
          }
        }
      }
    };

    const tick = () => {
      raf = 0;
      if (dirty) {
        dirty = false;
        recompute();
      }
    };
    const schedule = () => {
      dirty = true;
      if (!raf) raf = requestAnimationFrame(tick);
    };

    // wire data-reveal-delay -> CSS var, once
    document.querySelectorAll('.reveal').forEach(el => {
      const d = el.getAttribute('data-reveal-delay');
      if (d) el.style.setProperty('--reveal-delay', d + 'ms');
    });

    // initial paint after layout settles
    schedule();
    setTimeout(schedule, 60);
    setTimeout(schedule, 200);

    window.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', schedule);

    // Re-scan when new .reveal elements get added (e.g. async children)
    const mo = new MutationObserver(schedule);
    mo.observe(document.body, { childList: true, subtree: true });

    return () => {
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', schedule);
      mo.disconnect();
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);
}
window.useReveal = useReveal;
