function Footer() {
  return (
    <footer className="footer" id="contact">
      <div className="container">
        <p className="small">Have a project in mind?</p>
        <a href="mailto:ishan@virginia.edu" className="email-link">ishan@virginia.edu</a>
        <div className="credit">
          Designed & built by Ishan A.
          <div className="repo-stats">
            <span>★ open source</span>
            <span>UVA · CS '27</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
window.Footer = Footer;
