const PROJECTS = [
  { title: 'Crosswizard',  stack: ['Python', 'OpenCV', 'OCR'],          tag: 'CW' },
  { title: 'Munch.AI',     stack: ['Next.js', 'Tailwind', 'OpenAI'],     tag: 'MA' },
  { title: 'GeneSIS',      stack: ['React', 'Flask', 'Postgres'],        tag: 'GS' },
  { title: 'NavTJ',        stack: ['Flutter', 'Dart'],                   tag: 'NT' },
  { title: 'StudentVue.py', stack: ['Python', 'BeautifulSoup'],          tag: 'SV' },
  { title: 'FaceID',       stack: ['Python', 'PyTorch', 'CV'],           tag: 'FI' },
];

function Projects() {
  const [hovered, setHovered] = React.useState(null);
  const previewRef = React.useRef(null);
  const containerRef = React.useRef(null);

  const onMove = (e) => {
    if (!containerRef.current || !previewRef.current) return;
    if (window.innerWidth < 768) return;
    const rect = containerRef.current.getBoundingClientRect();
    const yWithin = e.clientY - rect.top;
    previewRef.current.style.transform = `translateY(${Math.max(0, yWithin - 180)}px)`;
  };

  return (
    <section className="section" id="selected-projects">
      <div className="container">
        <SectionTitle title="Selected Projects" />

        <div
          ref={containerRef}
          className="project-list"
          style={{ position: 'relative' }}
          onMouseMove={onMove}
          onMouseLeave={() => setHovered(null)}
        >
          <div
            ref={previewRef}
            className={'proj-preview ' + (hovered !== null ? 'show' : '')}
          >
            <div className="ph">{hovered !== null ? PROJECTS[hovered].title : ''}</div>
          </div>

          {PROJECTS.map((p, i) => (
            <a key={p.title} href="#" className="project-row reveal"
               data-reveal-delay={i * 50}
               onMouseEnter={() => setHovered(i)}>
              <span className="num">_{String(i+1).padStart(2,'0')}.</span>
              <div>
                <h3 className="title">{p.title}</h3>
                <div className="stack">
                  {p.stack.map((s, idx) => (
                    <React.Fragment key={s}>
                      <span>{s}</span>
                      {idx < p.stack.length - 1 && <span className="dot"></span>}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
window.Projects = Projects;
