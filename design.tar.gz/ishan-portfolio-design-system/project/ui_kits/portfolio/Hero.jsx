// Rotating hero headline + slide-up-and-fade reveal
const HERO_ROLES = [
  { lead: 'SOFTWARE',   tail: 'ENGINEER'   },
  { lead: 'AI / ML',    tail: 'ENTHUSIAST' },
  { lead: 'STUDENT',    tail: 'BUILDER'    },
];

function Hero() {
  const [idx, setIdx] = React.useState(0);
  const [phase, setPhase] = React.useState('in'); // 'in' | 'out'

  React.useEffect(() => {
    // cycle every 3.4s — out (400ms) then swap then in
    const t1 = setTimeout(() => setPhase('out'), 3000);
    const t2 = setTimeout(() => {
      setIdx(i => (i + 1) % HERO_ROLES.length);
      setPhase('in');
    }, 3400);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [idx]);

  const role = HERO_ROLES[idx];

  return (
    <section className="hero" id="banner">
      <div className="container" style={{ position: 'relative' }}>
        <div style={{ maxWidth: 600 }} className="hero-inner">
          <h1 className="reveal" data-reveal-delay="0">
            <span className={`role-line role-${phase}`} key={`a-${idx}`}>
              <span className="accent">{role.lead}</span>
            </span>
            <br />
            <span className={`role-line role-${phase}`} key={`b-${idx}`} style={{ marginLeft: 24, display: 'inline-block', animationDelay: '40ms' }}>
              {role.tail}
            </span>
          </h1>
          <p className="lead reveal" data-reveal-delay="80">
            Hi! I'm <b style={{ fontWeight: 500, color: 'var(--fg)' }}>Ishan</b>. A CS student at UVA building tools at the intersection of software engineering and AI/ML — focused on responsive interfaces, data-driven systems, and the occasional CV experiment.
          </p>
          <a href="mailto:ishan@virginia.edu" className="btn btn-primary reveal" data-reveal-delay="160">
            <span>Let's Talk</span>
          </a>
          <div className="availability reveal" data-reveal-delay="220">
            <span className="dot"></span>
            <span>Open for summer 2026 internships</span>
          </div>
        </div>

        <div className="stats" style={{
          position: 'absolute', right: 24, bottom: 0, textAlign: 'right',
        }}>
          <div className="reveal" data-reveal-delay="120">
            <div className="stat-num">3+</div>
            <div className="stat-lbl">Years coding</div>
          </div>
          <div className="reveal" data-reveal-delay="180">
            <div className="stat-num">12+</div>
            <div className="stat-lbl">Projects shipped</div>
          </div>
          <div className="reveal" data-reveal-delay="240">
            <div className="stat-num">2027</div>
            <div className="stat-lbl">UVA Grad</div>
          </div>
        </div>
      </div>

      <svg className="arrow-anim hero-arrow" width="280" height="80" viewBox="0 0 376 111" fill="none">
        <path d="M1 1V39.9286L188 110V70.6822L1 1Z" stroke="#3F7D3A" strokeWidth="1.5"/>
        <path d="M375 1V39.9286L188 110V70.6822L375 1Z" stroke="#3F7D3A" strokeWidth="1.5"/>
      </svg>
    </section>
  );
}
window.Hero = Hero;
