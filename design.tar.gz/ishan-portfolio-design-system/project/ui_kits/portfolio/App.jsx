function ScrollBar() {
  const [pct, setPct] = React.useState(0);
  React.useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setPct(h > 0 ? (window.scrollY / h) : 0);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <div className="scroll-bar">
      <div style={{ transform: `scaleY(${pct})` }}></div>
    </div>
  );
}

function StickyEmail() {
  return (
    <a className="sticky-email" href="mailto:ishan@virginia.edu">ishan@virginia.edu</a>
  );
}

function App() {
  useReveal();
  const onNav = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  return (
    <>
      <Cursor />
      <Particles />
      <Navbar onNav={onNav} />
      <ScrollBar />
      <StickyEmail />
      <main>
        <Hero />
        <AboutMe />
        <Skills />
        <Experiences />
        <Projects />
        <Footer />
      </main>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
